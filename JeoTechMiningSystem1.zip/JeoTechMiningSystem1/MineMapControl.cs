﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using JeoTechMiningSystem1.Algorithms;

namespace JeoTechMiningSystem1
{
    public class MineMapControl : UserControl
    {
        private int personnelX = 720;
        private int personnelY = 520;

        private List<MineNode> currentRoute;

        public MineMapControl()
        {
            this.BackColor =
                Color.FromArgb(5, 9, 14);

            this.Dock =
                DockStyle.Fill;

            currentRoute =
                new List<MineNode>();

            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw,
                true);
        }

        public void SetPersonnelPosition(
            int x,
            int y)
        {
            personnelX = x;
            personnelY = y;

            Invalidate();
        }

        public void SetRoute(
            List<MineNode> route)
        {
            if (route == null)
            {
                currentRoute =
                    new List<MineNode>();
            }
            else
            {
                currentRoute =
                    new List<MineNode>(route);
            }

            Invalidate();
        }

        protected override void OnPaint(
            PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g =
                e.Graphics;

            g.SmoothingMode =
                SmoothingMode.AntiAlias;

            DrawBackground(g);
            DrawMine(g);
            DrawIoTModules(g);
            DrawPersonnel(g);
            DrawExit(g);
            DrawSecondExit(g);
            DrawShelter(g);
            DrawRoute(g);
            DrawLabels(g);
        }

        private void DrawBackground(
            Graphics g)
        {
            using (LinearGradientBrush brush =
                new LinearGradientBrush(
                    ClientRectangle,
                    Color.FromArgb(4, 8, 12),
                    Color.FromArgb(12, 18, 24),
                    90))
            {
                g.FillRectangle(
                    brush,
                    ClientRectangle);
            }

            using (Pen gridPen =
                new Pen(
                    Color.FromArgb(
                        15,
                        35,
                        42),
                    1))
            {
                for (
                    int x = 0;
                    x < Width;
                    x += 40)
                {
                    g.DrawLine(
                        gridPen,
                        x,
                        0,
                        x,
                        Height);
                }

                for (
                    int y = 0;
                    y < Height;
                    y += 40)
                {
                    g.DrawLine(
                        gridPen,
                        0,
                        y,
                        Width,
                        y);
                }
            }
        }

        private void DrawMine(
            Graphics g)
        {
            // ANA TÜNEL
            DrawTunnel(
                g,
                170,
                180,
                520,
                180,
                42);

            // ANA ÇIKIŞA İNEN SOL TÜNEL
            DrawTunnel(
                g,
                170,
                180,
                170,
                320,
                38);

            // SOL KAVŞAK
            DrawTunnel(
                g,
                170,
                320,
                340,
                320,
                38);

            // ORTA ANA DİKEY TÜNEL
            DrawTunnel(
                g,
                520,
                180,
                520,
                420,
                42);

            // ÜST SAĞ TÜNEL
            DrawTunnel(
                g,
                520,
                180,
                720,
                300,
                42);

            DrawTunnel(
                g,
                720,
                300,
                950,
                300,
                38);

            // SOL ALT BÖLÜM
            DrawTunnel(
                g,
                340,
                320,
                340,
                540,
                38);

            DrawTunnel(
                g,
                340,
                540,
                350,
                650,
                38);

            DrawTunnel(
                g,
                340,
                540,
                150,
                540,
                38);

            // TEHLİKELİ BÖLGE
            DrawDangerTunnel(
                g,
                150,
                540,
                60,
                540,
                38);

            // ORTA ALT TÜNELLER
            DrawTunnel(
                g,
                520,
                420,
                350,
                540,
                38);

            DrawTunnel(
                g,
                520,
                420,
                720,
                420,
                38);

            // SAĞ DİKEY TÜNEL
            DrawTunnel(
                g,
                720,
                300,
                720,
                520,
                38);

            // IoT-04 TÜNELÜ
            DrawTunnel(
                g,
                720,
                520,
                900,
                520,
                38);

            // ALT ALTERNATİF YOL
            DrawTunnel(
                g,
                720,
                520,
                520,
                650,
                38);

            DrawTunnel(
                g,
                520,
                650,
                350,
                650,
                38);

            // SAĞ ÇIKIŞ KORİDORU
            DrawTunnel(
                g,
                950,
                300,
                1080,
                300,
                38);
        }

        private void DrawTunnel(
            Graphics g,
            int x1,
            int y1,
            int x2,
            int y2,
            int width)
        {
            using (Pen shadow =
                new Pen(
                    Color.FromArgb(
                        25,
                        30,
                        35),
                    width + 12))
            {
                g.DrawLine(
                    shadow,
                    x1 + 5,
                    y1 + 7,
                    x2 + 5,
                    y2 + 7);
            }

            using (Pen tunnel =
                new Pen(
                    Color.FromArgb(
                        55,
                        65,
                        72),
                    width))
            {
                g.DrawLine(
                    tunnel,
                    x1,
                    y1,
                    x2,
                    y2);
            }

            using (Pen edge =
                new Pen(
                    Color.FromArgb(
                        90,
                        105,
                        112),
                    3))
            {
                g.DrawLine(
                    edge,
                    x1,
                    y1,
                    x2,
                    y2);
            }

            using (Pen light =
                new Pen(
                    Color.FromArgb(
                        25,
                        130,
                        155),
                    2))
            {
                g.DrawLine(
                    light,
                    x1,
                    y1 - width / 2 + 4,
                    x2,
                    y2 - width / 2 + 4);
            }
        }

        private void DrawDangerTunnel(
            Graphics g,
            int x1,
            int y1,
            int x2,
            int y2,
            int width)
        {
            DrawTunnel(
                g,
                x1,
                y1,
                x2,
                y2,
                width);

            using (Pen glow =
                new Pen(
                    Color.FromArgb(
                        100,
                        255,
                        40,
                        40),
                    width + 10))
            {
                glow.StartCap =
                    LineCap.Round;

                glow.EndCap =
                    LineCap.Round;

                g.DrawLine(
                    glow,
                    x1,
                    y1,
                    x2,
                    y2);
            }

            using (Pen danger =
                new Pen(
                    Color.FromArgb(
                        220,
                        45,
                        45),
                    width - 8))
            {
                danger.StartCap =
                    LineCap.Round;

                danger.EndCap =
                    LineCap.Round;

                g.DrawLine(
                    danger,
                    x1,
                    y1,
                    x2,
                    y2);
            }
        }

        private void DrawIoTModules(
            Graphics g)
        {
            DrawIoTModule(
                g,
                340,
                320,
                "IoT-01");

            DrawIoTModule(
                g,
                520,
                420,
                "IoT-02");

            DrawIoTModule(
                g,
                720,
                300,
                "IoT-03");

            DrawIoTModule(
                g,
                720,
                520,
                "IoT-04");
        }

        private void DrawIoTModule(
            Graphics g,
            int x,
            int y,
            string id)
        {
            using (Pen glow =
                new Pen(
                    Color.FromArgb(
                        70,
                        0,
                        191,
                        255),
                    16))
            {
                g.DrawEllipse(
                    glow,
                    x - 8,
                    y - 8,
                    16,
                    16);
            }

            using (SolidBrush brush =
                new SolidBrush(
                    Color.DeepSkyBlue))
            {
                g.FillEllipse(
                    brush,
                    x - 8,
                    y - 8,
                    16,
                    16);
            }

            using (Font font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold))
            using (SolidBrush text =
                new SolidBrush(
                    Color.White))
            {
                g.DrawString(
                    id,
                    font,
                    text,
                    x + 13,
                    y - 10);
            }
        }

        private void DrawPersonnel(
            Graphics g)
        {
            DrawPerson(
                g,
                personnelX,
                personnelY,
                "BARET");
        }

        private void DrawPerson(
            Graphics g,
            int x,
            int y,
            string id)
        {
            using (Pen glow =
                new Pen(
                    Color.FromArgb(
                        100,
                        255,
                        215,
                        0),
                    10))
            {
                g.DrawEllipse(
                    glow,
                    x - 11,
                    y - 11,
                    22,
                    22);
            }

            using (SolidBrush helmet =
                new SolidBrush(
                    Color.Gold))
            {
                g.FillEllipse(
                    helmet,
                    x - 10,
                    y - 10,
                    20,
                    20);
            }

            using (SolidBrush center =
                new SolidBrush(
                    Color.DeepSkyBlue))
            {
                g.FillEllipse(
                    center,
                    x - 5,
                    y - 5,
                    10,
                    10);
            }

            using (Font font =
                new Font(
                    "Segoe UI",
                    8,
                    FontStyle.Bold))
            using (SolidBrush text =
                new SolidBrush(
                    Color.White))
            {
                g.DrawString(
                    id,
                    font,
                    text,
                    x + 14,
                    y - 8);
            }
        }

        private void DrawExit(
            Graphics g)
        {
            using (SolidBrush brush =
                new SolidBrush(
                    Color.FromArgb(
                        30,
                        220,
                        120)))
            {
                g.FillRectangle(
                    brush,
                    145,
                    145,
                    50,
                    35);
            }

            using (Pen border =
                new Pen(
                    Color.LimeGreen,
                    2))
            {
                g.DrawRectangle(
                    border,
                    145,
                    145,
                    50,
                    35);
            }
        }

        private void DrawSecondExit(
            Graphics g)
        {
            using (SolidBrush brush =
                new SolidBrush(
                    Color.FromArgb(
                        25,
                        170,
                        100)))
            {
                g.FillRectangle(
                    brush,
                    945,
                    265,
                    50,
                    35);
            }

            using (Pen border =
                new Pen(
                    Color.LimeGreen,
                    2))
            {
                g.DrawRectangle(
                    border,
                    945,
                    265,
                    50,
                    35);
            }
        }

        private void DrawShelter(
            Graphics g)
        {
            using (SolidBrush brush =
                new SolidBrush(
                    Color.FromArgb(
                        25,
                        100,
                        150)))
            {
                g.FillRectangle(
                    brush,
                    830,
                    440,
                    90,
                    60);
            }

            using (Pen border =
                new Pen(
                    Color.Cyan,
                    2))
            {
                g.DrawRectangle(
                    border,
                    830,
                    440,
                    90,
                    60);
            }

            using (Font font =
                new Font(
                    "Segoe UI",
                    8,
                    FontStyle.Bold))
            using (SolidBrush text =
                new SolidBrush(
                    Color.White))
            {
                g.DrawString(
                    "SIĞINMA",
                    font,
                    text,
                    842,
                    452);

                g.DrawString(
                    "ODASI",
                    font,
                    text,
                    850,
                    470);
            }
        }

        private void DrawRoute(
            Graphics g)
        {
            if (currentRoute == null)
                return;

            if (currentRoute.Count < 2)
                return;

            Point[] route =
                new Point[currentRoute.Count];

            for (
                int i = 0;
                i < currentRoute.Count;
                i++)
            {
                route[i] =
                    new Point(
                        (int)currentRoute[i].X,
                        (int)currentRoute[i].Y);
            }

            // Rota dış parıltısı
            using (Pen glow =
                new Pen(
                    Color.FromArgb(
                        70,
                        0,
                        255,
                        150),
                    14))
            {
                glow.StartCap =
                    LineCap.Round;

                glow.EndCap =
                    LineCap.Round;

                glow.LineJoin =
                    LineJoin.Round;

                g.DrawLines(
                    glow,
                    route);
            }

            // Ana rota
            using (Pen routePen =
                new Pen(
                    Color.FromArgb(
                        60,
                        255,
                        190),
                    5))
            {
                routePen.StartCap =
                    LineCap.Round;

                routePen.EndCap =
                    LineCap.Round;

                routePen.LineJoin =
                    LineJoin.Round;

                g.DrawLines(
                    routePen,
                    route);
            }

            // Rota üzerindeki noktalar
            for (
                int i = 0;
                i < route.Length;
                i++)
            {
                using (SolidBrush pointBrush =
                    new SolidBrush(
                        Color.FromArgb(
                            60,
                            255,
                            190)))
                {
                    g.FillEllipse(
                        pointBrush,
                        route[i].X - 4,
                        route[i].Y - 4,
                        8,
                        8);
                }
            }
        }

        private void DrawLabels(
            Graphics g)
        {
            using (Font titleFont =
                new Font(
                    "Segoe UI",
                    18,
                    FontStyle.Bold))
            using (SolidBrush white =
                new SolidBrush(
                    Color.White))
            {
                g.DrawString(
                    "JEOTECH • UNDERGROUND MINE MAP",
                    titleFont,
                    white,
                    25,
                    20);
            }

            using (Font smallFont =
                new Font(
                    "Segoe UI",
                    9))
            using (SolidBrush gray =
                new SolidBrush(
                    Color.LightGray))
            {
                g.DrawString(
                    "AUTONOMOUS EVACUATION MONITORING • DEMO",
                    smallFont,
                    gray,
                    28,
                    50);

                // ANA ÇIKIŞ
                g.DrawString(
                    "ANA ÇIKIŞ",
                    smallFont,
                    Brushes.White,
                    140,
                    125);

                // ÇIKIŞ 2
                // Yazı doğrudan çıkışın üstünde.
                g.DrawString(
                    "ALTERNATİF ÇIKIŞ",
                    smallFont,
                    Brushes.White,
                    925,
                    245);

                // TEHLİKELİ BÖLGE
                g.DrawString(
                    "TEHLİKELİ BÖLGE",
                    smallFont,
                    Brushes.Red,
                    80,
                    565);
            }
        }
    }
}

