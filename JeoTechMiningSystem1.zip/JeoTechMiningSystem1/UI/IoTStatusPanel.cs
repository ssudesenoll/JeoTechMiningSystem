﻿using System;
using System.Drawing;
using System.Windows.Forms;
using JeoTechMiningSystem1.Models;

namespace JeoTechMiningSystem1.UI
{
    public class IoTStatusPanel : Panel
    {
        private Label titleLabel;
        private Label moduleLabel;
        private Label gasLabel;
        private Label temperatureLabel;
        private Label statusLabel;

        public IoTStatusPanel()
        {
            Width = 220;
            Height = 130;
            BackColor = Color.FromArgb(15, 20, 27);
            BorderStyle = BorderStyle.FixedSingle;

            CreateLabels();
        }

        private void CreateLabels()
        {
            titleLabel = new Label();
            titleLabel.Text = "IoT MODÜL";
            titleLabel.Font = new Font(
                "Segoe UI",
                10,
                FontStyle.Bold);
            titleLabel.ForeColor = Color.DeepSkyBlue;
            titleLabel.Location = new Point(12, 8);
            titleLabel.AutoSize = true;

            moduleLabel = new Label();
            moduleLabel.Text = "IoT-01";
            moduleLabel.Font = new Font(
                "Segoe UI",
                11,
                FontStyle.Bold);
            moduleLabel.ForeColor = Color.White;
            moduleLabel.Location = new Point(12, 32);
            moduleLabel.AutoSize = true;

            gasLabel = new Label();
            gasLabel.Text = "Gaz: --";
            gasLabel.ForeColor = Color.LightGray;
            gasLabel.Location = new Point(12, 58);
            gasLabel.AutoSize = true;

            temperatureLabel = new Label();
            temperatureLabel.Text = "Sıcaklık: --";
            temperatureLabel.ForeColor = Color.LightGray;
            temperatureLabel.Location = new Point(12, 78);
            temperatureLabel.AutoSize = true;

            statusLabel = new Label();
            statusLabel.Text = "● BAĞLI DEĞİL";
            statusLabel.ForeColor = Color.Gray;
            statusLabel.Location = new Point(12, 100);
            statusLabel.AutoSize = true;

            Controls.Add(titleLabel);
            Controls.Add(moduleLabel);
            Controls.Add(gasLabel);
            Controls.Add(temperatureLabel);
            Controls.Add(statusLabel);
        }

        public void UpdateData(SensorData data)
        {
            if (data == null)
                return;

            moduleLabel.Text = "IoT-" + data.ModuleId;
            gasLabel.Text = "Gaz: " +
                data.GasValue.ToString("0.00");

            temperatureLabel.Text = "Sıcaklık: " +
                data.Temperature.ToString("0.0") +
                " °C";

            if (data.IsConnected)
            {
                statusLabel.Text = "● BAĞLI";
                statusLabel.ForeColor = Color.LimeGreen;
            }
            else
            {
                statusLabel.Text = "● BAĞLI DEĞİL";
                statusLabel.ForeColor = Color.Gray;
            }
        }
    }
}
