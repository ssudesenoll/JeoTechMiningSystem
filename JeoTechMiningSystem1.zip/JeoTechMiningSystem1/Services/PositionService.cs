﻿using System;
using System.Collections.Generic;
using System.Drawing;
using JeoTechMiningSystem1.Models;

namespace JeoTechMiningSystem1.Services
{
    public class PositionService
    {
        private List<PositionNode> positionNodes;

        private Point[] iotPositions =
        {
            new Point(340, 320), // IoT-01
            new Point(520, 420), // IoT-02
            new Point(720, 300), // IoT-03
            new Point(720, 520)  // IoT-04
        };

        public PositionService()
        {
            positionNodes = new List<PositionNode>();

            // ==========================================
            // BARET TEST KONUMları
            // ==========================================

            // P1 - Üst ana yatay tünel
            positionNodes.Add(
                new PositionNode(
                    "P1",
                    430,
                    180,
                    FindNearestIoT(430, 180)));

            // P2 - Sol dikey tünel
            positionNodes.Add(
                new PositionNode(
                    "P2",
                    340,
                    450,
                    FindNearestIoT(340, 450)));

            // P3 - Sağ üst yatay tünel
            positionNodes.Add(
                new PositionNode(
                    "P3",
                    850,
                    300,
                    FindNearestIoT(850, 300)));

            // P4 - EN ALTTAKİ YATAY TÜNEL
            positionNodes.Add(
                new PositionNode(
                    "P4",
                    520,
                    650,
                    FindNearestIoT(520, 650)));
        }

        private int FindNearestIoT(int x, int y)
        {
            double shortestDistance = double.MaxValue;

            int nearestIoT = 1;

            for (int i = 0;
                 i < iotPositions.Length;
                 i++)
            {
                double dx =
                    x - iotPositions[i].X;

                double dy =
                    y - iotPositions[i].Y;

                double distance =
                    Math.Sqrt(
                        (dx * dx) +
                        (dy * dy));

                if (distance < shortestDistance)
                {
                    shortestDistance = distance;
                    nearestIoT = i + 1;
                }
            }

            return nearestIoT;
        }

        public PositionNode GetPosition(
            string nodeId)
        {
            foreach (
                PositionNode node
                in positionNodes)
            {
                if (node.NodeId == nodeId)
                {
                    return node;
                }
            }

            return null;
        }

        public List<PositionNode>
            GetAllPositions()
        {
            return positionNodes;
        }
    }
}