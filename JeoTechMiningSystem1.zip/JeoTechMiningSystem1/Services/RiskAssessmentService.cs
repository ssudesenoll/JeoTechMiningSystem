﻿using JeoTechMiningSystem1.Models;

namespace JeoTechMiningSystem1.Services
{
    public class RiskAssessmentService
    {
        // PROTOTİP TEST EŞİĞİ
        // MQ-4'ün ham analog okumasıdır.
        // PPM veya %CH4 değildir.
        public const double GasTestThreshold = 500;

        public double CalculateRisk(SensorData data)
        {
            if (data == null)
                return 0;

            double risk = 0;

            // MQ-4 gaz testi
            if (data.GasValue >= GasTestThreshold)
            {
                risk += 60;
            }

            // LM35 sıcaklık risk faktörü
            if (data.Temperature >= 35)
            {
                risk += 20;
            }

            if (data.Temperature >= 45)
            {
                risk += 20;
            }

            if (risk > 100)
                risk = 100;

            return risk;
        }

        public string GetRiskLevel(double risk)
        {
            if (risk >= 80)
                return "KRİTİK";

            if (risk >= 60)
                return "YÜKSEK";

            if (risk >= 20)
                return "UYARI";

            return "NORMAL";
        }
    }
}