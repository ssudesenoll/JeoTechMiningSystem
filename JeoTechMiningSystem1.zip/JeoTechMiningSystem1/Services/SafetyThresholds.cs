﻿namespace JeoTechMiningSystem1.Services
{
    public static class SafetyThresholds
    {
        // PROTOTİP / DEMO EŞİKLERİ
        // Gerçek maden güvenlik sınırı değildir.

        // MQ-4 için Arduino analog okuma:
        // 0 - 1023
        public const double GasWarning = 400;
        public const double GasCritical = 700;

        // LM35:
        // Sıcaklık °C olarak değerlendirilir.
        public const double TemperatureWarning = 40;
        public const double TemperatureCritical = 60;
    }
}