﻿using System.Collections.Generic;
using JeoTechMiningSystem1.Algorithms;
using JeoTechMiningSystem1.Models;

namespace JeoTechMiningSystem1.Services
{
    public class MineDataService
    {
        public MineGraph Graph { get; private set; }

        public IoTSystem IoTSystem { get; private set; }

        public MineDataService()
        {
            Graph = new MineGraph();
            IoTSystem = new IoTSystem();
        }

        public void UpdateModuleData(
            int moduleId,
            double gasValue,
            double temperature)
        {
            IoTModule module = IoTSystem.GetModule(moduleId);

            if (module == null)
                return;

            module.SensorData.GasValue = gasValue;
            module.SensorData.Temperature = temperature;
            module.IsOnline = true;
            module.SensorData.IsConnected = true;
        }

        public void SetModuleDanger(
            int moduleId,
            bool dangerous)
        {
            MineNode node = Graph.GetNode("IoT-" + moduleId);

            if (node != null)
            {
                node.IsDangerous = dangerous;
            }
        }

        public List<IoTModule> GetModules()
        {
            return IoTSystem.Modules;
        }
    }
}
