﻿using System.Collections.Generic;
using JeoTechMiningSystem1.Models;

namespace JeoTechMiningSystem1.Services
{
    public class IoTSystem
    {
        public List<IoTModule> Modules { get; private set; }

        public IoTSystem()
        {
            Modules = new List<IoTModule>();

            // Prototipte kullanılacak 4 IoT modülü
            for (int i = 1; i <= 4; i++)
            {
                Modules.Add(new IoTModule(i));
            }
        }

        public IoTModule GetModule(int moduleId)
        {
            return Modules.Find(m => m.ModuleId == moduleId);
        }
    }
}
