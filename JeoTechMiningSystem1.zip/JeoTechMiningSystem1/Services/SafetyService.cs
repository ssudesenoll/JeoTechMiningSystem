﻿using System.Collections.Generic;
using JeoTechMiningSystem1.Models;

namespace JeoTechMiningSystem1.Services
{
    public class SafetyService
    {
        // Sensör verisini değerlendirir.
        // Gaz VEYA sıcaklık tehlikeliyse true döner.
        public bool EvaluateSensorData(SensorData sensorData)
        {
            if (sensorData == null)
                return false;

            if (sensorData.GasDanger)
                return true;

            if (sensorData.TemperatureDanger)
                return true;

            return false;
        }

        // IoT modülünün genel durumunu kontrol eder.
        public bool IsDangerous(IoTModule module)
        {
            if (module == null)
                return false;

            return EvaluateSensorData(
                module.SensorData);
        }

        // Tehlikeli IoT modüllerini bulur.
        public List<IoTModule> GetDangerousModules(
            List<IoTModule> modules)
        {
            List<IoTModule> dangerousModules =
                new List<IoTModule>();

            if (modules == null)
                return dangerousModules;

            foreach (IoTModule module in modules)
            {
                if (IsDangerous(module))
                {
                    dangerousModules.Add(module);
                }
            }

            return dangerousModules;
        }
    }
}

