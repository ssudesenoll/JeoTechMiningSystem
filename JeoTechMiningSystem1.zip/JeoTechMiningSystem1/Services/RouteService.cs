﻿using System;
using System.Collections.Generic;
using JeoTechMiningSystem1.Algorithms;
using JeoTechMiningSystem1.Models;

namespace JeoTechMiningSystem1.Services
{
    public class RouteService
    {
        private PositionService positionService;
        private MineGraph mineGraph;
        private DijkstraAlgorithm dijkstra;
        private SafetyService safetyService;

        public RouteService()
        {
            positionService =
                new PositionService();

            mineGraph =
                new MineGraph();

            dijkstra =
                new DijkstraAlgorithm();

            safetyService =
                new SafetyService();
        }

        // ==================================================
        // EN GÜVENLİ VE EN KISA ÇIKIŞ ROTASINI BUL
        // ==================================================

        public List<MineNode> CalculateRoute(
            string helmetId)
        {
            PositionNode position =
                positionService.GetPosition(
                    helmetId);

            if (position == null)
            {
                return new List<MineNode>();
            }

            MineNode startNode =
                mineGraph.GetNode(
                    position.NodeId);

            if (startNode == null)
            {
                return new List<MineNode>();
            }

            // ==================================================
            // ANA ÇIKIŞ ROTASI
            // ==================================================

            List<MineNode> mainExitRoute =
                dijkstra.FindShortestPath(
                    mineGraph,
                    startNode.Id,
                    "EXIT");

            // ==================================================
            // ALTERNATİF ÇIKIŞ ROTASI
            // ==================================================

            List<MineNode> alternativeExitRoute =
                dijkstra.FindShortestPath(
                    mineGraph,
                    startNode.Id,
                    "EXIT-2");

            // ==================================================
            // ANA ÇIKIŞA ULAŞILAMIYORSA
            // ALTERNATİFİ KULLAN
            // ==================================================

            if (IsValidRoute(alternativeExitRoute) &&
                !IsValidRoute(mainExitRoute))
            {
                return alternativeExitRoute;
            }

            // ==================================================
            // ALTERNATİF ÇIKIŞA ULAŞILAMIYORSA
            // ANA ÇIKIŞI KULLAN
            // ==================================================

            if (IsValidRoute(mainExitRoute) &&
                !IsValidRoute(alternativeExitRoute))
            {
                return mainExitRoute;
            }

            // ==================================================
            // İKİ ÇIKIŞE DE ULAŞILAMIYORSA
            // ==================================================

            if (!IsValidRoute(mainExitRoute) &&
                !IsValidRoute(alternativeExitRoute))
            {
                return new List<MineNode>();
            }

            // ==================================================
            // İKİ ÇIKIŞ DE GÜVENLİYSE
            // KISA OLANI SEÇ
            // ==================================================

            double mainDistance =
                CalculateRouteDistance(
                    mainExitRoute);

            double alternativeDistance =
                CalculateRouteDistance(
                    alternativeExitRoute);

            if (alternativeDistance <
                mainDistance)
            {
                return alternativeExitRoute;
            }

            return mainExitRoute;
        }

        // ==================================================
        // ROTANIN GEÇERLİ OLUP OLMADIĞINI KONTROL ET
        // ==================================================

        private bool IsValidRoute(
            List<MineNode> route)
        {
            if (route == null)
                return false;

            if (route.Count == 0)
                return false;

            return true;
        }

        // ==================================================
        // ROTA MESAFESİNİ HESAPLA
        // ==================================================

        private double CalculateRouteDistance(
            List<MineNode> route)
        {
            if (route == null ||
                route.Count < 2)
            {
                return 0;
            }

            double totalDistance = 0;

            for (int i = 0;
                 i < route.Count - 1;
                 i++)
            {
                MineNode first =
                    route[i];

                MineNode second =
                    route[i + 1];

                double dx =
                    first.X - second.X;

                double dy =
                    first.Y - second.Y;

                double distance =
                    Math.Sqrt(
                        dx * dx +
                        dy * dy);

                totalDistance +=
                    distance;
            }

            return totalDistance;
        }

        // ==================================================
        // SENSÖR DURUMLARINI GRAFA AKTAR
        // ==================================================

        public void UpdateDangerousModules(
            List<IoTModule> modules)
        {
            SetAllModulesSafe();

            if (modules == null)
                return;

            foreach (IoTModule module in modules)
            {
                if (module == null)
                    continue;

                bool dangerous =
                    safetyService.IsDangerous(
                        module);

                if (dangerous)
                {
                    SetModuleDangerous(
                        module.ModuleId,
                        true);
                }
            }
        }

        // ==================================================
        // TÜM IoT BÖLGELERİNİ GÜVENLİ YAP
        // ==================================================

        private void SetAllModulesSafe()
        {
            SetModuleDangerous(1, false);
            SetModuleDangerous(2, false);
            SetModuleDangerous(3, false);
            SetModuleDangerous(4, false);
        }

        // ==================================================
        // IoT MODÜLÜNÜ TEHLİKELİ/GÜVENLİ YAP
        // ==================================================

        private void SetModuleDangerous(
            int moduleId,
            bool dangerous)
        {
            string nodeId =
                "IoT-" + moduleId;

            SetNodeDangerous(
                nodeId,
                dangerous);
        }

        // ==================================================
        // MINE GRAPH NODE DURUMU
        // ==================================================

        private void SetNodeDangerous(
            string nodeId,
            bool dangerous)
        {
            MineNode node =
                mineGraph.GetNode(
                    nodeId);

            if (node != null)
            {
                node.IsDangerous =
                    dangerous;
            }
        }

        // ==================================================
        // GRAFE ERİŞİM
        // ==================================================

        public MineGraph GetMineGraph()
        {
            return mineGraph;
        }
    }
}