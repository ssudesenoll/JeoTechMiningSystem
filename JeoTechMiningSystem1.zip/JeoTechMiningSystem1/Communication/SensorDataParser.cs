﻿using System;
using JeoTechMiningSystem1.Models;

namespace JeoTechMiningSystem1.Communication
{
    public class SensorDataParser
    {
        public bool TryParse(
            string message,
            out SensorData sensorData)
        {
            sensorData = null;

            if (string.IsNullOrWhiteSpace(message))
                return false;

            string[] parts = message.Split(',');

            if (parts.Length != 3)
                return false;

            int moduleId;
            double gasValue;
            double temperature;

            if (!int.TryParse(parts[0], out moduleId))
                return false;

            if (!double.TryParse(
                parts[1],
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out gasValue))
            {
                return false;
            }

            if (!double.TryParse(
                parts[2],
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out temperature))
            {
                return false;
            }

            sensorData = new SensorData
            {
                ModuleId = moduleId,
                GasValue = gasValue,
                Temperature = temperature,
                IsConnected = true
            };

            return true;
        }
    }
}
