﻿using System;
using System.IO.Ports;

namespace JeoTechMiningSystem1.Communication
{
    public class SerialCommunication
    {
        private SerialPort serialPort;

        public bool IsConnected
        {
            get
            {
                return serialPort != null && serialPort.IsOpen;
            }
        }

        public event Action<string> DataReceived;

        public SerialCommunication()
        {
            serialPort = new SerialPort();
            serialPort.BaudRate = 9600;
            serialPort.DataBits = 8;
            serialPort.Parity = Parity.None;
            serialPort.StopBits = StopBits.One;

            serialPort.DataReceived += SerialPort_DataReceived;
        }

        public void Connect(string portName)
        {
            if (serialPort.IsOpen)
                serialPort.Close();

            serialPort.PortName = portName;
            serialPort.Open();
        }

        public void Disconnect()
        {
            if (serialPort.IsOpen)
                serialPort.Close();
        }

        public void Send(string message)
        {
            if (!serialPort.IsOpen)
                return;

            serialPort.WriteLine(message);
        }

        private void SerialPort_DataReceived(
            object sender,
            SerialDataReceivedEventArgs e)
        {
            try
            {
                string data = serialPort.ReadLine();

                if (DataReceived != null)
                {
                    DataReceived(data.Trim());
                }
            }
            catch
            {
                // Haberleşme sırasında oluşan geçici
                // okuma hatalarını şimdilik yok sayıyoruz.
            }
        }
    }
}