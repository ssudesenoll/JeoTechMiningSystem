﻿using System;
using JeoTechMiningSystem1.Models;
using JeoTechMiningSystem1.Services;

namespace JeoTechMiningSystem1.Communication
{
    public class CommunicationService
    {
        private readonly SerialCommunication serialCommunication;
        private readonly SensorDataParser parser;
        private readonly MineDataService mineDataService;
        private readonly SafetyService safetyService;

        public event Action<SensorData> SensorDataReceived;

        public CommunicationService(MineDataService mineDataService)
        {
            this.mineDataService = mineDataService;

            serialCommunication = new SerialCommunication();
            parser = new SensorDataParser();

            // SafetyService burada oluşturuluyor.
            safetyService = new SafetyService();

            serialCommunication.DataReceived += OnSerialDataReceived;
        }

        public bool IsConnected
        {
            get { return serialCommunication.IsConnected; }
        }

        public void Connect(string portName)
        {
            serialCommunication.Connect(portName);
        }

        public void Disconnect()
        {
            serialCommunication.Disconnect();
        }

        public void Send(string message)
        {
            serialCommunication.Send(message);
        }

        private void OnSerialDataReceived(string message)
        {
            SensorData sensorData;

            if (!parser.TryParse(message, out sensorData))
                return;

            mineDataService.UpdateModuleData(
                sensorData.ModuleId,
                sensorData.GasValue,
                sensorData.Temperature);

            // Sensör verisini güvenlik sistemine gönder.
            safetyService.EvaluateSensorData(sensorData);

            if (SensorDataReceived != null)
            {
                SensorDataReceived(sensorData);
            }
        }
    }
}