﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using JeoTechMiningSystem1.Algorithms;
using JeoTechMiningSystem1.Models;
using JeoTechMiningSystem1.Services;

namespace JeoTechMiningSystem1
{
    public partial class Form1 : Form
    {
        private MineMapControl mineMapControl;
        private PositionService positionService;
        private RouteService routeService;

        private ComboBox positionComboBox;
        private Label positionLabel;

        private Button normalButton;
        private Button dangerButton;

        private Label routeStatusLabel;
        private Label routeDistanceLabel;

        private List<IoTModule> modules;

        public Form1()
        {
            InitializeComponent();

            this.BackColor = Color.FromArgb(5, 10, 15);

            positionService = new PositionService();
            routeService = new RouteService();

            // ==========================================
            // IoT MODÜLLERİ
            // ==========================================

            modules = new List<IoTModule>();

            modules.Add(new IoTModule(1));
            modules.Add(new IoTModule(2));
            modules.Add(new IoTModule(3));
            modules.Add(new IoTModule(4));

            // ==========================================
            // HARİTA
            // ==========================================

            mineMapControl = new MineMapControl();
            mineMapControl.Dock = DockStyle.Fill;

            this.Controls.Add(mineMapControl);

            // ==========================================
            // KONTROLLER
            // ==========================================

            CreatePositionControls();
            CreateSensorButtons();
            CreateRouteInfoControls();

            // ==========================================
            // BAŞLANGIÇTA TÜM SENSÖRLER GÜVENLİ
            // ==========================================

            CreateDemoSensorData();

            // Başlangıç rotasını göster
            UpdateHelmetPositionAndRoute();
        }

        // ==================================================
        // BARET KONUMU KONTROLLERİ
        // ==================================================

        private void CreatePositionControls()
        {
            positionComboBox = new ComboBox();

            positionComboBox.Width = 180;
            positionComboBox.Height = 30;

            positionComboBox.Left = 25;
            positionComboBox.Top = 80;

            positionComboBox.DropDownStyle =
                ComboBoxStyle.DropDownList;

            positionComboBox.Items.Add("P1 - IoT-01");
            positionComboBox.Items.Add("P2 - IoT-02");
            positionComboBox.Items.Add("P3 - IoT-03");
            positionComboBox.Items.Add("P4 - IoT-04");

            positionComboBox.SelectedIndex = 0;

            positionComboBox.SelectedIndexChanged +=
                PositionComboBox_SelectedIndexChanged;

            this.Controls.Add(positionComboBox);
            positionComboBox.BringToFront();

            positionLabel = new Label();

            positionLabel.Text = "BARET KONUMU";

            positionLabel.ForeColor = Color.White;
            positionLabel.BackColor =
                Color.FromArgb(20, 25, 30);

            positionLabel.AutoSize = true;

            positionLabel.Left = 25;
            positionLabel.Top = 60;

            this.Controls.Add(positionLabel);
            positionLabel.BringToFront();
        }

        // ==================================================
        // SENSÖR BUTONLARI
        // ==================================================

        private void CreateSensorButtons()
        {
            // ==========================================
            // NORMAL BUTONU
            // ==========================================

            normalButton = new Button();

            normalButton.Text =
                "SENSÖRLER NORMAL";

            normalButton.Width = 180;
            normalButton.Height = 35;

            normalButton.Left = 25;
            normalButton.Top = 125;

            normalButton.BackColor =
                Color.FromArgb(20, 100, 70);

            normalButton.ForeColor =
                Color.White;

            normalButton.FlatStyle =
                FlatStyle.Flat;

            normalButton.Click +=
                NormalButton_Click;

            this.Controls.Add(normalButton);
            normalButton.BringToFront();

            // ==========================================
            // TEHLİKE BUTONU
            // ==========================================

            dangerButton = new Button();

            dangerButton.Text =
                "TEHLİKE SENARYOSU";

            dangerButton.Width = 180;
            dangerButton.Height = 35;

            dangerButton.Left = 25;
            dangerButton.Top = 165;

            dangerButton.BackColor =
                Color.FromArgb(150, 40, 40);

            dangerButton.ForeColor =
                Color.White;

            dangerButton.FlatStyle =
                FlatStyle.Flat;

            dangerButton.Click +=
                DangerButton_Click;

            this.Controls.Add(dangerButton);
            dangerButton.BringToFront();
        }

        // ==================================================
        // ROTA BİLGİ KONTROLLERİ
        // ==================================================

        private void CreateRouteInfoControls()
        {
            // ==========================================
            // ROTA DURUMU
            // ==========================================

            routeStatusLabel = new Label();

            routeStatusLabel.Text =
                "ROTA: HESAPLANIYOR...";

            routeStatusLabel.Width = 300;
            routeStatusLabel.Height = 30;

            routeStatusLabel.Left = 25;
            routeStatusLabel.Top = 215;

            routeStatusLabel.ForeColor =
                Color.White;

            routeStatusLabel.BackColor =
                Color.FromArgb(20, 25, 30);

            routeStatusLabel.Font =
                new Font(
                    "Arial",
                    10,
                    FontStyle.Bold);

            this.Controls.Add(routeStatusLabel);
            routeStatusLabel.BringToFront();

            // ==========================================
            // ROTA MESAFESİ
            // ==========================================

            routeDistanceLabel = new Label();

            routeDistanceLabel.Text =
                "MESAFE: -";

            routeDistanceLabel.Width = 300;
            routeDistanceLabel.Height = 25;

            routeDistanceLabel.Left = 25;
            routeDistanceLabel.Top = 250;

            routeDistanceLabel.ForeColor =
                Color.White;

            routeDistanceLabel.BackColor =
                Color.FromArgb(20, 25, 30);

            routeDistanceLabel.Font =
                new Font(
                    "Arial",
                    9);

            this.Controls.Add(routeDistanceLabel);
            routeDistanceLabel.BringToFront();
        }

        // ==================================================
        // BAŞLANGIÇ SENSÖR VERİSİ
        // ==================================================

        private void CreateDemoSensorData()
        {
            if (modules == null)
                return;

            // IoT-01
            modules[0].SensorData.GasDanger = false;
            modules[0].SensorData.TemperatureDanger = false;
            modules[0].SensorData.IsConnected = true;

            // IoT-02
            modules[1].SensorData.GasDanger = false;
            modules[1].SensorData.TemperatureDanger = false;
            modules[1].SensorData.IsConnected = true;

            // IoT-03
            modules[2].SensorData.GasDanger = false;
            modules[2].SensorData.TemperatureDanger = false;
            modules[2].SensorData.IsConnected = true;

            // IoT-04
            modules[3].SensorData.GasDanger = false;
            modules[3].SensorData.TemperatureDanger = false;
            modules[3].SensorData.IsConnected = true;

            routeService.UpdateDangerousModules(
                modules);
        }

        // ==================================================
        // NORMAL SENARYO
        // ==================================================

        private void NormalButton_Click(
            object sender,
            EventArgs e)
        {
            SetAllSensorsSafe();

            routeService.UpdateDangerousModules(
                modules);

            UpdateHelmetPositionAndRoute();
        }

        // ==================================================
        // TEHLİKE SENARYOSU
        // ==================================================

        private void DangerButton_Click(
            object sender,
            EventArgs e)
        {
            // ==========================================
            // IoT-01 TEHLİKELİ
            // ==========================================

            modules[0].SensorData.GasDanger = true;

            modules[0].SensorData.TemperatureDanger =
                true;

            // ==========================================
            // IoT-02 TEHLİKELİ
            // ==========================================

            modules[1].SensorData.GasDanger = true;

            modules[1].SensorData.TemperatureDanger =
                true;

            // ==========================================
            // IoT-03 GÜVENLİ
            // ==========================================

            modules[2].SensorData.GasDanger = false;

            modules[2].SensorData.TemperatureDanger =
                false;

            // ==========================================
            // IoT-04 GÜVENLİ
            // ==========================================

            modules[3].SensorData.GasDanger = false;

            modules[3].SensorData.TemperatureDanger =
                false;

            // ==========================================
            // TEHLİKEYİ GRAFA AKTAR
            // ==========================================

            routeService.UpdateDangerousModules(
                modules);

            // ==========================================
            // YENİ GÜVENLİ ROTAYI HESAPLA
            // ==========================================

            UpdateHelmetPositionAndRoute();
        }

        // ==================================================
        // TÜM SENSÖRLERİ GÜVENLİ YAP
        // ==================================================

        private void SetAllSensorsSafe()
        {
            if (modules == null)
                return;

            foreach (IoTModule module in modules)
            {
                if (module == null)
                    continue;

                module.SensorData.GasDanger =
                    false;

                module.SensorData.TemperatureDanger =
                    false;

                module.SensorData.IsConnected =
                    true;
            }
        }

        // ==================================================
        // BARET SEÇİMİ
        // ==================================================

        private void PositionComboBox_SelectedIndexChanged(
            object sender,
            EventArgs e)
        {
            UpdateHelmetPositionAndRoute();
        }

        // ==================================================
        // BARET KONUMU + ROTA
        // ==================================================

        private void UpdateHelmetPositionAndRoute()
        {
            if (positionComboBox == null)
                return;

            if (positionComboBox.SelectedItem == null)
                return;

            string selectedPosition =
                positionComboBox.SelectedItem.ToString();

            string nodeId =
                selectedPosition.Substring(0, 2);

            PositionNode position =
                positionService.GetPosition(nodeId);

            if (position == null)
                return;

            // ==========================================
            // BARETİN HARİTADAKİ KONUMU
            // ==========================================

            mineMapControl.SetPersonnelPosition(
                position.X,
                position.Y);

            positionLabel.Text =
                "BARET KONUMU: " +
                position.NodeId +
                " | IoT-" +
                position.NearestIoT;

            // ==========================================
            // GÜNCEL GÜVENLİ ROTAYI HESAPLA
            // ==========================================

            List<MineNode> route =
                routeService.CalculateRoute(
                    nodeId);

            // ==========================================
            // ROTAYI HARİTAYA GÖNDER
            // ==========================================

            mineMapControl.SetRoute(route);

            // ==========================================
            // ROTA YOKSA
            // ==========================================

            if (route == null ||
                route.Count == 0)
            {
                routeStatusLabel.Text =
                    "ROTA: GÜVENLİ ÇIKIŞ YOK";

                routeDistanceLabel.Text =
                    "MESAFE: -";

                return;
            }

            // ==========================================
            // SEÇİLEN ÇIKIŞ
            // ==========================================

            MineNode exitNode =
                route[route.Count - 1];

            // ==========================================
            // ROTA MESAFESİ
            // ==========================================

            double totalDistance = 0;

            for (int i = 0;
                 i < route.Count - 1;
                 i++)
            {
                double dx =
                    route[i].X -
                    route[i + 1].X;

                double dy =
                    route[i].Y -
                    route[i + 1].Y;

                double distance =
                    Math.Sqrt(
                        dx * dx +
                        dy * dy);

                totalDistance +=
                    distance;
            }

            // ==========================================
            // ÇIKIŞ KARARINI GÖSTER
            // ==========================================

            if (exitNode.Id == "EXIT")
            {
                routeStatusLabel.Text =
                    "ROTA: ANA ÇIKIŞ";
            }
            else if (exitNode.Id == "EXIT-2")
            {
                routeStatusLabel.Text =
                    "ROTA: ALTERNATİF ÇIKIŞ";
            }
            else
            {
                routeStatusLabel.Text =
                    "ROTA: BELİRLENEMEDİ";
            }

            // ==========================================
            // MESAFEYİ GÖSTER
            // ==========================================

            routeDistanceLabel.Text =
                "MESAFE: " +
                Math.Round(
                    totalDistance,
                    1) +
                " birim";
        }
    }
}