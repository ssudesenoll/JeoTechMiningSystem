﻿using System.Collections.Generic;

namespace JeoTechMiningSystem1.Algorithms
{
    public class MineGraph
    {
        public List<MineNode> Nodes { get; private set; }

        public MineGraph()
        {
            Nodes = new List<MineNode>();

            CreateMineMap();
        }

        private void CreateMineMap()
        {
            // =========================
            // ÇIKIŞ
            // =========================

            MineNode exit = new MineNode(
                "EXIT",
                170,
                185);

            // =========================
            // ANA KAVŞAKLAR
            // =========================

            MineNode junction1 = new MineNode(
                "J1",
                520,
                185);

            MineNode junction2 = new MineNode(
                "J2",
                340,
                320);

            MineNode junction3 = new MineNode(
                "J3",
                520,
                420);

            MineNode junction4 = new MineNode(
                "J4",
                720,
                300);

            MineNode junction5 = new MineNode(
                "J5",
                720,
                520);

            MineNode junction6 = new MineNode(
                "J6",
                520,
                650);

            MineNode junction7 = new MineNode(
                "J7",
                340,
                650);

            // =========================
            // IoT MODÜLLERİ
            // =========================

            MineNode iot1 = new MineNode(
                "IoT-01",
                340,
                320);

            MineNode iot2 = new MineNode(
                "IoT-02",
                520,
                420);

            MineNode iot3 = new MineNode(
                "IoT-03",
                720,
                300);

            MineNode iot4 = new MineNode(
                "IoT-04",
                720,
                520);

            // =========================
            // SAĞ ÇIKIŞ
            // =========================

            MineNode exit2 = new MineNode(
                "EXIT-2",
                950,
                300);

            // =========================
            // NODE'LARI EKLE
            // =========================

            Nodes.Add(exit);

            Nodes.Add(junction1);
            Nodes.Add(junction2);
            Nodes.Add(junction3);
            Nodes.Add(junction4);
            Nodes.Add(junction5);
            Nodes.Add(junction6);
            Nodes.Add(junction7);

            Nodes.Add(iot1);
            Nodes.Add(iot2);
            Nodes.Add(iot3);
            Nodes.Add(iot4);

            Nodes.Add(exit2);

            // =========================
            // TÜNEL BAĞLANTILARI
            // =========================

            // ANA ÇIKIŞ
            Connect(exit, junction1);

            // ÜST TÜNEL
            Connect(junction1, junction4);

            // SOL BÖLGE
            Connect(junction1, junction2);

            // IoT-01
            Connect(junction2, iot1);

            Connect(iot1, junction3);

            // IoT-02
            Connect(junction3, iot2);

            // ORTA TÜNEL
            Connect(junction3, junction5);

            // IoT-03
            Connect(junction4, iot3);

            Connect(iot3, exit2);

            // IoT-04
            Connect(junction5, iot4);

            // ALT ALTERNATİF YOL
            Connect(iot4, junction6);

            Connect(junction6, junction7);

            Connect(junction7, junction2);
        }

        private void Connect(
            MineNode first,
            MineNode second)
        {
            if (!first.Neighbors.Contains(second))
            {
                first.Neighbors.Add(second);
            }

            if (!second.Neighbors.Contains(first))
            {
                second.Neighbors.Add(first);
            }
        }

        public MineNode GetNode(
            string id)
        {
            return Nodes.Find(
                node => node.Id == id);
        }

        public void SetDangerous(
            string nodeId,
            bool dangerous)
        {
            MineNode node =
                GetNode(nodeId);

            if (node != null)
            {
                node.IsDangerous =
                    dangerous;
            }
        }

        public void ClearDangerous()
        {
            foreach (
                MineNode node in Nodes)
            {
                node.IsDangerous = false;
            }
        }
    }
}