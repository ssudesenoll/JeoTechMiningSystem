﻿using System;
using System.Collections.Generic;

namespace JeoTechMiningSystem1.Algorithms
{
    public class SafeRouteAlgorithm
    {
        public List<MineNode> FindSafestRoute(
            MineGraph graph,
            MineNode start,
            MineNode target)
        {
            var distances = new Dictionary<MineNode, double>();
            var previous = new Dictionary<MineNode, MineNode>();
            var unvisited = new List<MineNode>();

            foreach (MineNode node in graph.Nodes)
            {
                distances[node] = double.MaxValue;
                previous[node] = null;
                unvisited.Add(node);
            }

            distances[start] = 0;

            while (unvisited.Count > 0)
            {
                MineNode current = GetLowestDistanceNode(
                    unvisited,
                    distances);

                if (current == null)
                    break;

                unvisited.Remove(current);

                if (current == target)
                    break;

                foreach (MineNode neighbor in current.Neighbors)
                {
                    // Tehlikeli düğümden geçişi engelle
                    if (neighbor.IsDangerous)
                        continue;

                    double distance = CalculateDistance(
                        current,
                        neighbor);

                    double riskCost = CalculateRiskCost(neighbor);

                    double newDistance =
                        distances[current] +
                        distance +
                        riskCost;

                    if (newDistance < distances[neighbor])
                    {
                        distances[neighbor] = newDistance;
                        previous[neighbor] = current;
                    }
                }
            }

            return BuildRoute(previous, start, target);
        }

        private MineNode GetLowestDistanceNode(
            List<MineNode> nodes,
            Dictionary<MineNode, double> distances)
        {
            MineNode lowestNode = null;
            double lowestDistance = double.MaxValue;

            foreach (MineNode node in nodes)
            {
                if (distances[node] < lowestDistance)
                {
                    lowestDistance = distances[node];
                    lowestNode = node;
                }
            }

            return lowestNode;
        }

        private double CalculateDistance(
            MineNode first,
            MineNode second)
        {
            double dx = first.X - second.X;
            double dy = first.Y - second.Y;

            return Math.Sqrt(
                dx * dx +
                dy * dy);
        }

        private double CalculateRiskCost(MineNode node)
        {
            if (node.IsDangerous)
                return double.MaxValue;

            return 0;
        }

        private List<MineNode> BuildRoute(
            Dictionary<MineNode, MineNode> previous,
            MineNode start,
            MineNode target)
        {
            List<MineNode> route = new List<MineNode>();

            MineNode current = target;

            while (current != null)
            {
                route.Insert(0, current);

                if (current == start)
                    break;

                current = previous[current];
            }

            if (route.Count == 0 || route[0] != start)
                return new List<MineNode>();

            return route;
        }
    }
}
