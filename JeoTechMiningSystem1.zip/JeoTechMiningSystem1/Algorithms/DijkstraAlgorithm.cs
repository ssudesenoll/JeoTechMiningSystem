﻿using System;
using System.Collections.Generic;

namespace JeoTechMiningSystem1.Algorithms
{
    public class DijkstraAlgorithm
    {
        public List<MineNode> FindShortestPath(
            MineGraph graph,
            string startId,
            string targetId)
        {
            MineNode start =
                graph.GetNode(startId);

            MineNode target =
                graph.GetNode(targetId);

            if (start == null || target == null)
            {
                return new List<MineNode>();
            }

            Dictionary<MineNode, double> distances =
                new Dictionary<MineNode, double>();

            Dictionary<MineNode, MineNode> previous =
                new Dictionary<MineNode, MineNode>();

            List<MineNode> unvisited =
                new List<MineNode>();

            foreach (MineNode node in graph.Nodes)
            {
                distances[node] =
                    double.MaxValue;

                previous[node] =
                    null;

                unvisited.Add(node);
            }

            distances[start] = 0;

            while (unvisited.Count > 0)
            {
                MineNode current = null;

                double smallestDistance =
                    double.MaxValue;

                foreach (MineNode node in unvisited)
                {
                    if (distances[node] <
                        smallestDistance)
                    {
                        smallestDistance =
                            distances[node];

                        current = node;
                    }
                }

                if (current == null)
                    break;

                unvisited.Remove(current);

                if (current == target)
                    break;

                // Tehlikeli bölgeye girme
                foreach (
                    MineNode neighbor
                    in current.Neighbors)
                {
                    if (neighbor.IsDangerous &&
                        neighbor != target)
                    {
                        continue;
                    }

                    if (!unvisited.Contains(
                        neighbor))
                    {
                        continue;
                    }

                    double distance =
                        distances[current] +
                        CalculateDistance(
                            current,
                            neighbor);

                    if (distance <
                        distances[neighbor])
                    {
                        distances[neighbor] =
                            distance;

                        previous[neighbor] =
                            current;
                    }
                }
            }

            if (distances[target] ==
                double.MaxValue)
            {
                return new List<MineNode>();
            }

            List<MineNode> path =
                new List<MineNode>();

            MineNode step = target;

            while (step != null)
            {
                path.Insert(0, step);

                step =
                    previous[step];
            }

            return path;
        }

        private double CalculateDistance(
            MineNode first,
            MineNode second)
        {
            double dx =
                first.X - second.X;

            double dy =
                first.Y - second.Y;

            return Math.Sqrt(
                dx * dx +
                dy * dy);
        }
    }
}