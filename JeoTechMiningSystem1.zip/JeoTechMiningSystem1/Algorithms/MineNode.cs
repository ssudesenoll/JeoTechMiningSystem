﻿using System.Collections.Generic;

namespace JeoTechMiningSystem1.Algorithms
{
    public class MineNode
    {
        public string Id { get; set; }

        public float X { get; set; }

        public float Y { get; set; }

        public bool IsDangerous { get; set; }

        public List<MineNode> Neighbors { get; set; }

        public MineNode(
            string id,
            float x,
            float y)
        {
            Id = id;
            X = x;
            Y = y;

            // Başlangıçta bütün bölgeler güvenli
            IsDangerous = false;

            Neighbors =
                new List<MineNode>();
        }
    }
}