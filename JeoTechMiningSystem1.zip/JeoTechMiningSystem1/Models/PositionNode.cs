﻿namespace JeoTechMiningSystem1.Models
{
    public class PositionNode
    {
        public string NodeId { get; set; }

        public int X { get; set; }

        public int Y { get; set; }

        public int NearestIoT { get; set; }

        public PositionNode(
            string nodeId,
            int x,
            int y,
            int nearestIoT)
        {
            NodeId = nodeId;
            X = x;
            Y = y;
            NearestIoT = nearestIoT;
        }
    }
}