﻿namespace JeoTechMiningSystem1.Models
{
    public class SensorData
    {
        public int ModuleId { get; set; }

        public double GasValue { get; set; }

        public double Temperature { get; set; }

        public bool GasDanger { get; set; }

        public bool TemperatureDanger { get; set; }

        public bool IsConnected { get; set; }

        public SensorData()
        {
            IsConnected = false;
            GasDanger = false;
            TemperatureDanger = false;
        }
    }
}
