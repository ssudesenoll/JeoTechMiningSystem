﻿using System;

namespace JeoTechMiningSystem1.Models
{
    public class IoTModule
    {
        public int ModuleId { get; set; }

        public string ModuleName { get; set; }

        public SensorData SensorData { get; set; }

        public bool IsOnline { get; set; }

        public IoTModule(int moduleId)
        {
            ModuleId = moduleId;
            ModuleName = "IoT-" + moduleId;
            SensorData = new SensorData
            {
                ModuleId = moduleId
            };
            IsOnline = false;
        }
    }
}